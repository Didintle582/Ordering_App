﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CafeteriaAPP.Data;
using CafeteriaAPP.Models;
using CafeteriaAPP.ViewModels;
using System.Collections.Generic;

namespace CafeteriaAPP.Controllers
{
    public class OrderController : Controller
    {
        private readonly ApplicationDbContext _context;

        public OrderController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: /Order/Menu/5
        public async Task<IActionResult> Menu(int id)
        {
            var restaurant = await _context.Restaurants
                .Include(r => r.MenuItems)
                .FirstOrDefaultAsync(r => r.Id == id);

            if (restaurant == null)
                return NotFound();

            var viewModel = new PlaceOrder
            {
                Restaurant = restaurant,
                RestaurantId = id,
                MenuItems = restaurant.MenuItems.ToList()
            };

            return View(viewModel);
        }

        // POST: /Order/Menu
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Menu(PlaceOrder model)
        {
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.EmployeeNumber == model.EmployeeNumber);

            if (employee == null)
            {
                ModelState.AddModelError("", "Employee not found.");
                return View(model);
            }

            // Calculate total cost
            decimal total = 0;
            var orderItems = new List<OrderItem>();

            foreach (var item in model.Quantities)
            {
                if (item.Value > 0)
                {
                    var menuItem = await _context.MenuItems.FindAsync(item.Key);
                    if (menuItem == null) continue;

                    decimal itemTotal = item.Value * menuItem.Price;
                    total += itemTotal;

                    orderItems.Add(new OrderItem
                    {
                        MenuItemId = menuItem.Id,
                        Quantity = item.Value,
                        UnitPriceAtTimeOfOrder = menuItem.Price
                    });
                }
            }

            if (total == 0)
            {
                ModelState.AddModelError("", "You must select at least one item.");
                return View(model);
            }

            if (employee.Balance < total)
            {
                ModelState.AddModelError("", "Insufficient balance.");
                return View(model);
            }

            // Deduct and Save
            employee.Balance -= total;

            var order = new Order
            {
                EmployeeId = employee.Id,
                OrderDate = DateTime.Now,
                TotalAmount = total,
                Status = "Pending",
                OrderItems = orderItems
            };

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            ViewBag.Message = "Order placed successfully!";
            return RedirectToAction("Confirmation", new { id = order.Id });
        }

        public async Task<IActionResult> Confirmation(int id)
        {
            var order = await _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.MenuItem)
                .Include(o => o.Employee)
                .FirstOrDefaultAsync(o => o.Id == id);

            return View(order);
        }
    }
}
