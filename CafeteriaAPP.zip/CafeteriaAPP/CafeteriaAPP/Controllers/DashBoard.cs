﻿using Microsoft.AspNetCore.Mvc;

namespace CafeteriaAPP.Controllers
{
    public class DashBoard : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
