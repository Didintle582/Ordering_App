﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CafeteriaAPP.Models
{
    public class Resturant
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public string LocationDescription { get; set; }

        public string ContactNumber { get; set; }

        public ICollection<Menu> MenuItems { get; set; }
    }
}
