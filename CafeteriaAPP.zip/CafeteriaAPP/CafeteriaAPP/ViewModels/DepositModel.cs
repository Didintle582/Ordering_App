﻿namespace CafeteriaAPP.ViewModels
{
    public class DepositModel
    {
        public string EmployeeNumber { get; set; }
        public decimal DepositAmount { get; set; }
    }
}
