﻿using System.Collections.Generic;
using CafeteriaAPP.Models;

namespace CafeteriaAPP.ViewModels
{
    public class PlaceOrder
    {
        public string EmployeeNumber { get; set; }
        public int RestaurantId { get; set; }
        public Resturant Restaurant { get; set; }
        public List<Menu> MenuItems { get; set; }

        public Dictionary<int, int> Quantities { get; set; } = new(); // MenuItemId → Quantity
    }
}
